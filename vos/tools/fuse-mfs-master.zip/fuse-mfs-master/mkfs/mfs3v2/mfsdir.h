/* Directory entry structure; unchanged from V3 */
#include "../v3/mfsdir.h"
