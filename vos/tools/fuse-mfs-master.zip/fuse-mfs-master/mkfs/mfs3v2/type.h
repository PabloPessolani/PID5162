/* Inode structure; unchanged from regular V2; V3 is identical anyway */
#include "../v2/type.h"
