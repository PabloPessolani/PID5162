/* Inode structure; unchanged from regular V1 */
#include "../v1/type.h"
