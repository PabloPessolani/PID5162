/* Directory entry structure; unchanged from V1L */
#include "../v1l/mfsdir.h"
