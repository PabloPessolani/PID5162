/* Inode structure; unchanged from regular V2 */
#include "../v2/type.h"
