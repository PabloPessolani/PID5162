libtuntap bindings
==================

libtuntap supports bindings in C++ and Python, thanks to Fabien Pichot
(@drepdash on Github). This is a work in progress.

Support for more languages is planned.
