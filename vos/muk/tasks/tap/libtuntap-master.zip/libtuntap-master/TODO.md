# TODO

- [X] tuntap_get_descr() is not implemented in master
- [X] Define tuntap_get_fd() instead of TUNTAP_GET_FD macro
- [X] Split tuntap.h in two
- [ ] Use SIOCGIFADDR on OpenBSD to get the hwaddr
- [ ] Generate local hwaddr in tuntap_set_hwaddr
- [ ] Implement tuntap_get_debug

- [X] Test on OpenBSD
- [X] Test on NetBSD
- [ ] Test on FreeBSD
- [ ] Test on Darwin
- [X] Test on Debian
- [ ] Test on Windows
