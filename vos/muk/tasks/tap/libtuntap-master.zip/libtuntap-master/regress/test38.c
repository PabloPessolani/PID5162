/* Public domain - Tristan Le Guern <tleguern@bouledef.eu> */

int
main(void) {
	return 0;
}

