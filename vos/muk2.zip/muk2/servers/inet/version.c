/*
version.c
*/

#include "inet.h"

char version[]= "inet 0.79, last compiled on " __DATE__ " " __TIME__;

/*
 * $PchId: version.c,v 1.54 2005/06/28 14:35:01 philip Exp $
 */
