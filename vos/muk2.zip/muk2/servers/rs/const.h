/* Constants used by the Reincarnation Server */


