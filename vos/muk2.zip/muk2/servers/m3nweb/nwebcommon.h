
#define		NW_PROC_NR		INIT_PROC_NR

#define 	WEB_SOCKET		0	
#define 	WEB_CONNECT		1	
#define 	WEB_CLTWRITE	2
#define 	WEB_CLTREAD 	3

#define		WEBMAXBUF		(1024*64)

#define	SVR_ADDR		"192.168.1.100"
#define SVR_PORT        80

