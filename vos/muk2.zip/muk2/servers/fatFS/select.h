/* return codes for select_request_* and select_cancel_* */
#define SEL_OK		0	/* ready */
#define SEL_ERROR	1	/* failed */

