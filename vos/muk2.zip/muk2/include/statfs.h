/* Data for fstatfs() call. */

#ifndef _STATFS_H
#define _STATFS_H

struct statfs {
  mnx_off_t f_bsize;		/* file system block size */
};


#endif /* _STATFS_H */
