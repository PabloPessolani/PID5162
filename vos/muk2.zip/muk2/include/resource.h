#define PRIO_SYSTASK	-19
#define PRIO_PROXY	-19
#define PRIO_TASK	-15
#define PRIO_SERVER	-10
#define PRIO_USERPROC	 0
