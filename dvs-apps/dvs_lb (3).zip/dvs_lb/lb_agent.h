
/*
*Este archivo debe estar en LBAgent
*/
#include <sys/syscall.h>
//Representacion numerica de los Estados
#define LVL_UNLOADED 0
#define LVL_LOADED 1
#define LVL_SATURATED 2
//Estos son los valores techo que se van a pasar a los agentes


