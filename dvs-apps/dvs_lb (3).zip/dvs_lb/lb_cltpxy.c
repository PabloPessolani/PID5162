/****************************************************************/
/* 				LB_cltpxy							*/
/* LOAD BALANCER CLIENT PROXIES 				 		*/
/****************************************************************/

#define _GNU_SOURCE     
#define _MULTI_THREADED
#include "lb_dvs.h"

sess_entry_t *clt_Rproxy_2server(client_t *clt_ptr, service_t *svc_ptr);
int clt_Rproxy_svrmq(client_t *clt_ptr, server_t *svr_ptr, sess_entry_t *sess_ptr);
int clt_Rproxy_error(client_t *clt_ptr, int errcode); 
server_t *select_server(client_t *clt_ptr, 
						sess_entry_t *sess_ptr, 
						service_t *svc_ptr,
						proxy_hdr_t *hdr_ptr);
						
/*----------------------------------------------*/
/*----------------------------------------------*/
/*----------------------------------------------*/
/*      PROXY RECEIVER FUNCTIONS        */
/*----------------------------------------------*/
/*----------------------------------------------*/
/*----------------------------------------------*/
/*===========================================================================*
 *				   clt_Rproxy 				    					 *
 *===========================================================================*/
void *clt_Rproxy(void *arg)
{
	int clt_id = (int) arg;
   	client_t *clt_ptr;

	clt_ptr = &client_tab[clt_id];
	USRDEBUG("CLIENT_RPROXY[%s]: Initializing...\n", clt_ptr->clt_name);
	clt_Rproxy_init(clt_ptr);
	clt_Rproxy_loop(clt_ptr);
	USRDEBUG("CLIENT_RPROXY[%s]: Exiting...\n", clt_ptr->clt_name);
}	

void clt_Rproxy_init(client_t *clt_ptr) 
{
    int rcode;
	lbpx_desc_t *cpx_ptr; 

	cpx_ptr = &clt_ptr->clt_rpx;

	USRDEBUG("CLIENT_RPROXY(%s): Initializing proxy receiver\n", clt_ptr->clt_name);
	
	// Allocate buffer for msgq message (type + header)
	rcode = posix_memalign( (void**) &cpx_ptr->lbp_mqbuf, getpagesize(), (sizeof(msgq_buf_t)));
	if (rcode != 0) ERROR_EXIT(rcode);
	cpx_ptr->lbp_header = &cpx_ptr->lbp_mqbuf->mb_header;

	// Allocate buffer for payload 
	rcode = posix_memalign( (void**) &cpx_ptr->lbp_payload, getpagesize(), MAXCOPYBUF);
	if (rcode != 0) ERROR_EXIT(rcode);
	USRDEBUG("CLIENT_RPROXY(%s): Payload address=%p\n", clt_ptr->clt_name, cpx_ptr->lbp_payload);
	
    if( clt_Rproxy_setup(clt_ptr) != OK) ERROR_EXIT(errno);
	return(OK);
}

int clt_Rproxy_setup(client_t *clt_ptr) 
{
    int rcode;
    int optval = 1;
	lbpx_desc_t *cpx_ptr; 

	cpx_ptr = &clt_ptr->clt_rpx;
	
    cpx_ptr->lbp_port = (LBP_BASE_PORT+clt_ptr->clt_nodeid);
	USRDEBUG("CLIENT_RPROXY(%s): for node %d running at port=%d\n", 
		clt_ptr->clt_name, clt_ptr->clt_nodeid, cpx_ptr->lbp_port);

    // Create server socket.
    if ( (cpx_ptr->lbp_lsd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
        ERROR_EXIT(errno);

    if( (rcode = setsockopt(cpx_ptr->lbp_lsd, SOL_SOCKET, SO_REUSEADDR, 
							&optval, sizeof(optval))) < 0)
        	ERROR_EXIT(errno);

    // Bind (attach) this process to the server socket.
    cpx_ptr->lbp_rmtclt_addr.sin_family = AF_INET;
    cpx_ptr->lbp_rmtclt_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    cpx_ptr->lbp_rmtclt_addr.sin_port = htons(cpx_ptr->lbp_port);
	rcode = bind(cpx_ptr->lbp_lsd, (struct sockaddr *) &cpx_ptr->lbp_rmtclt_addr, 
					sizeof(cpx_ptr->lbp_rmtclt_addr));
    if(rcode < 0) ERROR_EXIT(errno);

	USRDEBUG("CLIENT_RPROXY(%s): is bound to port=%d socket=%d\n", 
		clt_ptr->clt_name, cpx_ptr->lbp_port, cpx_ptr->lbp_lsd);
		
// Turn 'rproxy_sd' to a listening socket. Listen queue size is 1.
	rcode = listen(cpx_ptr->lbp_lsd, 0);
    if(rcode < 0) ERROR_EXIT(errno);

    return(OK);
   
}

void clt_Rproxy_loop(client_t *clt_ptr)
{
	int sender_addrlen, i, ep;
    char ip4[INET_ADDRSTRLEN];  // space to hold the IPv4 string
    struct sockaddr_in sa;
    int rcode, dcid;
	server_t *svr_ptr;
	lbpx_desc_t *cpx_ptr;
	sess_entry_t *sess_ptr;
	service_t *svc_ptr;
	

	cpx_ptr = &clt_ptr->clt_rpx;
	
    while (1){
		do {
			sender_addrlen = sizeof(sa);
			USRDEBUG("CLIENT_RPROXY(%s): Waiting for connection.\n",
				clt_ptr->clt_name);
    		cpx_ptr->lbp_csd = accept(cpx_ptr->lbp_lsd, (struct sockaddr *) &sa, &sender_addrlen);
    		if(cpx_ptr->lbp_csd < 0) ERROR_PRINT(errno);
		}while(cpx_ptr->lbp_csd < 0);

    	/* Serve Forever */
		do { 
			USRDEBUG("CLIENT_RPROXY(%s): [%s]. Getting remote command.\n",
           		clt_ptr->clt_name, inet_ntop(AF_INET, &(sa.sin_addr), ip4, INET_ADDRSTRLEN));
	       	/* get a complete proxy message and process it */
       		rcode = clt_Rproxy_getcmd(clt_ptr);
       		if (rcode == OK) {
				USRDEBUG("CLIENT_RPROXY(%s):Message succesfully processed.\n",
					clt_ptr->clt_name);
				cpx_ptr->lbp_msg_ok++;
				
				for(i = 0; i < lb.lb_nr_services; i++){
					svc_ptr = &service_tab[i];
					USRDEBUG("CLIENT_RPROXY(%s): " SERVICE_FORMAT, 
						clt_ptr->clt_name, SERVICE_FIELDS(svc_ptr));	
					// check for matching DCID
					if( (svc_ptr->svc_dcid == LB_INVALID) // It means all DCIDs 
					||  (svc_ptr->svc_dcid == cpx_ptr->lbp_header->c_dcid)) { 
						// check if there is a service which listen in the destination endpoint
#ifdef SINGLE_ENDPOINT
						if(svc_ptr->svc_extep == cpx_ptr->lbp_header->c_dst)
							break;
#else // SINGLE_ENDPOINT
						USRDEBUG("CLIENT_RPROXY(%s): minep=%d  maxep=%d\n",
							clt_ptr->clt_name, svc_ptr->svc_minep, svc_ptr->svc_maxep);						
						for( ep = svc_ptr->svc_minep; ep <= svc_ptr->svc_maxep; ep++){
							USRDEBUG("CLIENT_RPROXY(%s): ep=%d\n", clt_ptr->clt_name, ep);	
							if(ep == cpx_ptr->lbp_header->c_dst) break;
						}
						if( ep > svc_ptr->svc_maxep) continue;
						USRDEBUG("CLIENT_RPROXY(%s): service endpoint found ep=%d\n",clt_ptr->clt_name,ep);						
						break;		
#endif // SINGLE_ENDPOINT
					}
				}
				// invalid destination endpoint -> send EDVSDSTDIED
				if( i == lb.lb_nr_services){
					rcode = clt_Rproxy_error(clt_ptr, EDVSDSTDIED);
					if( rcode < 0) ERROR_PRINT(-errno);
					continue;
				}
			
				// search for a existing session or create a new one 
				sess_ptr = clt_Rproxy_2server(clt_ptr, svc_ptr);
				if( sess_ptr == NULL) {
					ERROR_PRINT(EDVSAGAIN);
					continue;
				}
				dcid = cpx_ptr->lbp_header->c_dcid;
				MTX_LOCK(sess_table[dcid].st_mutex);
				svr_ptr = &server_tab[sess_ptr->se_svr_nodeid];
				MTX_UNLOCK(sess_table[dcid].st_mutex);

				rcode 	= clt_Rproxy_svrmq(clt_ptr, svr_ptr, sess_ptr);
				if( rcode < 0) ERROR_PRINT(rcode);
        	} else {
				USRDEBUG("CLIENT_RPROXY(%s): Message processing failure [%d]\n",
					clt_ptr->clt_name,rcode);
            	cpx_ptr->lbp_msg_err++;
				if( rcode == EDVSNOTCONN) break;
			}	
		}while(1);
		close(cpx_ptr->lbp_csd);
   	}
    /* never reached */
}

int clt_Rproxy_error(client_t *clt_ptr, int errcode)
{
	int rcode;
	lbpx_desc_t *cpx_ptr;
	lbpx_desc_t *clt_send_ptr;
	
	cpx_ptr 	= &clt_ptr->clt_rpx;
	clt_send_ptr= &clt_ptr->clt_spx;

	clock_gettime(clk_id, &cpx_ptr->lbp_header->c_timestamp);
	USRDEBUG("CLIENT_RPROXY(%s): Replying %d\n",clt_ptr->clt_name, errcode);
	cpx_ptr->lbp_mqbuf->mb_type  = LBP_CLT2CLT;
	cpx_ptr->lbp_header->c_cmd 	 = (cpx_ptr->lbp_header->c_cmd | MASK_ACKNOWLEDGE);
	cpx_ptr->lbp_header->c_rcode = errcode;
	cpx_ptr->lbp_header->c_dnode = cpx_ptr->lbp_header->c_snode;
	cpx_ptr->lbp_header->c_snode = lb.lb_nodeid;
	rcode 						 = cpx_ptr->lbp_header->c_dst;
	cpx_ptr->lbp_header->c_dst   = cpx_ptr->lbp_header->c_src;
	cpx_ptr->lbp_header->c_src   = rcode;
	rcode = msgsnd(clt_send_ptr->lbp_mqid, (char*) cpx_ptr->lbp_mqbuf, 
								sizeof(proxy_hdr_t), 0); 
	if(rcode < 0) ERROR_RETURN(-errno);
	return(rcode);
}
								
sess_entry_t *clt_Rproxy_2server(client_t *clt_ptr, service_t *svc_ptr)
{
	int rcode, i, max_sessions, dcid, new_ep;
	lbpx_desc_t *cpx_ptr;
	proxy_hdr_t *hdr_ptr;
	server_t *svr_ptr;
	sess_entry_t *sess_ptr;

	cpx_ptr = &clt_ptr->clt_rpx;
	assert(cpx_ptr->lbp_header != NULL);

	hdr_ptr = cpx_ptr->lbp_header;
	dcid	= hdr_ptr->c_dcid;
	if( dcid < 0 || dcid >= NR_DCS){
		ERROR_PRINT(EDVSBADDCID);
		return(NULL);
	}
	
	max_sessions =(NR_PROCS-NR_SYS_PROCS);
	
	USRDEBUG("CLIENT_RPROXY(%s): \n", clt_ptr->clt_name);
	sess_ptr = (sess_entry_t *)sess_table[dcid].st_tab_ptr;
	MTX_LOCK(sess_table[dcid].st_mutex);
	for( i = 0; i < max_sessions; i++, sess_ptr++){
//		MTX_LOCK(sess_table[dcid].st_mutex);
		if ( sess_ptr->se_clt_nodeid == LB_INVALID){
//			MTX_UNLOCK(sess_table[dcid].st_mutex);
			continue;
		}
		if (sess_ptr->se_clt_ep == hdr_ptr->c_src) {
			// Search for an Active Session 
			if( (sess_ptr->se_clt_nodeid == hdr_ptr->c_snode)
			&&  (sess_ptr->se_lbclt_ep	 == hdr_ptr->c_dst)
	//		&&  (sess_ptr->se_clt_PID	 == hdr_ptr->c_src_pid)
	//		&&  (sess_ptr->se_svr_PID	 == hdr_ptr->c_dst_pid)
			&&  (lb.lb_nodeid			 == hdr_ptr->c_dnode)){
				// ACTIVE SESSION FOUND 
				svr_ptr = &server_tab[sess_ptr->se_svr_nodeid];
				MTX_LOCK(svr_ptr->svr_mutex);
				// the CLIENT PID must be the same 
				if(sess_ptr->se_clt_PID != hdr_ptr->c_src_pid) {
					USRDEBUG("CLIENT_RPROXY(%s): Expired Session Found se_clt_PID=%d c_src_pid=%d\n", 
						clt_ptr->clt_name, sess_ptr->se_clt_PID, hdr_ptr->c_src_pid);
					// Create a new Session 	
					if( svc_ptr->svc_bind != PROG_BIND ){
						sprintf(sess_ptr->se_sshpass,	
							"sshpass -p \'root\' ssh root@%s "
							"-o UserKnownHostsFile=/dev/null "
							"-o StrictHostKeyChecking=no "
							"-o LogLevel=ERROR "
							" kill -s SIGKILL %d >> /tmp/%s.out 2>> /tmp/%s.err",
							svr_ptr->svr_name,								
							sess_ptr->se_svr_PID,
							svr_ptr->svr_name,								
							svr_ptr->svr_name							
						);
						USRDEBUG("CLIENT_RPROXY(%s): se_sshpass=%s\n", 		
								clt_ptr->clt_name, sess_ptr->se_sshpass);
						rcode = system(sess_ptr->se_sshpass);		
					}
					// Delete Session 
					sess_ptr->se_clt_nodeid = LB_INVALID;
					sess_ptr->se_clt_PID	= LB_INVALID;
					sess_ptr->se_svr_PID	= LB_INVALID;
					sess_ptr->se_service	= NULL;	
					sess_table[dcid].st_nr_sess--;
					CLR_BIT(svr_ptr->svr_bm_svc, sess_ptr->se_svr_ep);
					MTX_UNLOCK(svr_ptr->svr_mutex);
	//				MTX_UNLOCK(sess_table[dcid].st_mutex);
					break;
				}
				USRDEBUG("CLIENT_RPROXY(%s): Active Session Found with server %s\n", 
					clt_ptr->clt_name, svr_ptr->svr_name);
				USRDEBUG("CLIENT_RPROXY(%s):" SESE_CLT_FORMAT, 
						clt_ptr->clt_name, SESE_CLT_FIELDS(sess_ptr));
				USRDEBUG("CLIENT_RPROXY(%s):" SESE_SVR_FORMAT, 
						clt_ptr->clt_name, SESE_SVR_FIELDS(sess_ptr));
				USRDEBUG("CLIENT_RPROXY(%s):" SESE_LB_FORMAT, 
						clt_ptr->clt_name, SESE_LB_FIELDS(sess_ptr));			
				MTX_UNLOCK(svr_ptr->svr_mutex);	
				MTX_UNLOCK(sess_table[dcid].st_mutex);
				return(sess_ptr);
			}
//			MTX_UNLOCK(sess_table[dcid].st_mutex);
		} else {
			// Same destination endpoint from the same source node ??
			if( (sess_ptr->se_clt_nodeid == hdr_ptr->c_snode)
			&&  (sess_ptr->se_lbclt_ep	 == hdr_ptr->c_dst) ){
				rcode = clt_Rproxy_error(clt_ptr, EDVSRSCBUSY);
				MTX_UNLOCK(sess_table[dcid].st_mutex);
			}
		}
	}
	MTX_UNLOCK(sess_table[dcid].st_mutex);

	// check that src endpoint be a CLIENT ENDPOINT
	if( hdr_ptr->c_src < (NR_SYS_PROCS-NR_TASKS)
	||  hdr_ptr->c_dst < 0  
	||  hdr_ptr->c_dst >= (NR_SYS_PROCS-NR_TASKS)) {
		rcode = clt_Rproxy_error(clt_ptr, EDVSENDPOINT);
		if( rcode < 0) ERROR_PRINT(-errno);
		return(NULL);
	}			
	
	// NEW SESSION ------------------------------------ 

	// Search for a FREE session entry 
	sess_ptr = (sess_entry_t *)sess_table[dcid].st_tab_ptr;
	MTX_LOCK(sess_table[dcid].st_mutex);
	for( i = 0; i < max_sessions; i++, sess_ptr++){
		if ( sess_ptr->se_clt_nodeid == LB_INVALID) break;
	}
	if( i == max_sessions){
		rcode = clt_Rproxy_error(clt_ptr, EDVSNOSPC);
		if( rcode < 0) ERROR_PRINT(EDVSNOSPC);		
		MTX_UNLOCK(sess_table[dcid].st_mutex);
		return(NULL);
	}
	
	// sess_ptr LOCKED 
	svr_ptr = select_server(clt_ptr, sess_ptr, svc_ptr, hdr_ptr);
	if( svr_ptr == NULL) {
		rcode = clt_Rproxy_error(clt_ptr, EDVSDSTDIED);
		if( rcode < 0) 	ERROR_PRINT(EDVSNOSPC);
		MTX_UNLOCK(sess_table[dcid].st_mutex);		
		return(NULL);
	}
		
	sess_ptr->se_dcid 		= hdr_ptr->c_dcid;
	sess_ptr->se_clt_nodeid	= hdr_ptr->c_snode;
	sess_ptr->se_clt_ep		= hdr_ptr->c_src;
	sess_ptr->se_clt_PID	= hdr_ptr->c_src_pid;
	
	sess_ptr->se_lbclt_ep	= hdr_ptr->c_dst;
	sess_ptr->se_lbsvr_ep	= hdr_ptr->c_src; 	// could be different
	
//	new_ep = svc_ptr->svc_minep; // could be any from minep to maxep
//	sess_ptr->se_svr_ep		= new_ep; 
	
	sess_ptr->se_svr_nodeid	= svr_ptr->svr_nodeid;	
	sess_ptr->se_svr_PID	= LB_INVALID; 		
	sess_ptr->se_service 	= svc_ptr; 			
	sess_table[dcid].st_nr_sess++;

	USRDEBUG("CLIENT_RPROXY(%s): NEW Session with server %s\n", 
		clt_ptr->clt_name, svr_ptr->svr_name);
	USRDEBUG("CLIENT_RPROXY(%s):" SESE_CLT_FORMAT, 
			clt_ptr->clt_name, SESE_CLT_FIELDS(sess_ptr));
	USRDEBUG("CLIENT_RPROXY(%s):" SESE_SVR_FORMAT, 
			clt_ptr->clt_name, SESE_SVR_FIELDS(sess_ptr));
	USRDEBUG("CLIENT_RPROXY(%s):" SESE_LB_FORMAT, 
			clt_ptr->clt_name, SESE_LB_FIELDS(sess_ptr));

	MTX_UNLOCK(sess_table[dcid].st_mutex);
	
	return(sess_ptr);
}

// CHOOSE the first server with a load STATUS <  SATURATED 
server_t *select_server(client_t *clt_ptr, 
						sess_entry_t *sess_ptr, 
						service_t *svc_ptr,
						proxy_hdr_t *hdr_ptr)
{
	int i, new_ep, rcode;
	server_t *svr_ptr;

	for( i = 0; i < NR_NODES; i++){
		svr_ptr = &server_tab[i]; 
		MTX_LOCK(svr_ptr->svr_mutex);
		// TEMPORARY : CHOOSE THE FIRST
		if( svr_ptr->svr_nodeid != LB_INVALID) {
			// If server is SATURATED get the next
			if( svr_ptr->svr_level == LVL_SATURATED) {
				MTX_UNLOCK(svr_ptr->svr_mutex);
				continue;
			}
			for ( new_ep = svc_ptr->svc_minep; 
				  new_ep < svc_ptr->svc_maxep; new_ep++){
				if( TEST_BIT(svr_ptr->svr_bm_svc, new_ep) == 0) {
					// ALLOCATE FREE SERVER ENDPOINT
					SET_BIT(svr_ptr->svr_bm_svc, new_ep);
					if( svc_ptr->svc_bind != PROG_BIND 
					&&	svc_ptr->svc_prog != nonprog ){
						// sshpass [-ffilename|-dnum|-ppassword|-e] [options] command arguments
						// run_server.sh <dcid> <svr_ep> <clt_node> <clt_ep>"
						// sshpass -p 'root' ssh root@node1 -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o LogLevel=ERROR "bash -c \"
						sprintf(sess_ptr->se_sshpass, "sshpass -p \'root\' ssh root@%s "
													  "-o UserKnownHostsFile=/dev/null "
													  "-o StrictHostKeyChecking=no "
													  "-o LogLevel=ERROR "
													  " %s %d %d %d %d > /tmp/%s.out 2> /tmp/%s.err",
									svr_ptr->svr_name,				  
									svc_ptr->svc_prog, 								
									svc_ptr->svc_dcid, 
									new_ep,
									lb.lb_nodeid, 
									hdr_ptr->c_src,
									svr_ptr->svr_name,				  
									svr_ptr->svr_name				  
									);
						USRDEBUG("CLIENT_RPROXY(%s): se_sshpass=%s\n", 		
								clt_ptr->clt_name, sess_ptr->se_sshpass);
						rcode = system(sess_ptr->se_sshpass);
						if( rcode != 0) {
							CLR_BIT(svr_ptr->svr_bm_svc, new_ep);
							ERROR_PRINT(rcode);
						}
					}
					break;
				}
			}
			if( new_ep < svc_ptr->svc_maxep){
				MTX_UNLOCK(svr_ptr->svr_mutex);
				break;
				// choose another server 
			}
		}
		MTX_UNLOCK(svr_ptr->svr_mutex);
	}
	if ( i == NR_NODES){ // not free server found 
		ERROR_PRINT(EDVSNOSPC);
		return(NULL);	
	} 
	USRDEBUG("CLIENT_RPROXY(%s): server name=%s new_ep=%d\n", 		
								clt_ptr->clt_name, svr_ptr->svr_name, new_ep);
	sess_ptr->se_svr_ep	= new_ep; 
	return(svr_ptr);
}

int clt_Rproxy_getcmd(client_t *clt_ptr) 
{
    int rcode, pl_size, bytes;
	lbpx_desc_t *cpx_ptr, *clt_send_ptr; 

	cpx_ptr = &clt_ptr->clt_rpx;
	
	USRDEBUG("CLIENT_RPROXY(%s): \n", clt_ptr->clt_name);
	assert(cpx_ptr->lbp_header != NULL);
    do {
		bzero(cpx_ptr->lbp_header, sizeof(proxy_hdr_t));
		USRDEBUG("CLIENT_RPROXY(%s): About to receive header\n",
			clt_ptr->clt_name);
    	bytes = clt_Rproxy_rcvhdr(clt_ptr);
		USRDEBUG("CLIENT_RPROXY(%s): header bytes=%d\n",clt_ptr->clt_name, bytes); 
    	if (bytes < 0) ERROR_RETURN(bytes);
		if ( bytes == 0) {
			cpx_ptr->lbp_header->c_cmd == CMD_NONE;
			continue;
		}
		if( cpx_ptr->lbp_header->c_cmd != CMD_NONE) {
			USRDEBUG("CLIENT_RPROXY(%s): " CMD_FORMAT,
				clt_ptr->clt_name, CMD_FIELDS(cpx_ptr->lbp_header));
			USRDEBUG("CLIENT_RPROXY(%s): " CMD_XFORMAT,
				clt_ptr->clt_name, CMD_XFIELDS(cpx_ptr->lbp_header));
			USRDEBUG("CLIENT_RPROXY(%s): " CMD_TSFORMAT, 
				clt_ptr->clt_name, CMD_TSFIELDS(cpx_ptr->lbp_header)); 
			USRDEBUG("CLIENT_RPROXY(%s): "CMD_PIDFORMAT, 
				clt_ptr->clt_name, CMD_PIDFIELDS(cpx_ptr->lbp_header)); 
		} else {
				USRDEBUG("CLIENT_RPROXY(%s): NONE\n", clt_ptr->clt_name);
				// reverse the node fields 
				//	cpx_ptr->lbp_header->c_dnode = cpx_ptr->lbp_header->c_snode;
				//	cpx_ptr->lbp_header->c_snode = lb.lb_nodeid;
				clock_gettime(clk_id, &cpx_ptr->lbp_header->c_timestamp);
				USRDEBUG("CLIENT_RPROXY(%s): Replying NONE\n",clt_ptr->clt_name);
				cpx_ptr->lbp_mqbuf->mb_type = LBP_CLT2CLT;
				clt_send_ptr = &clt_ptr->clt_spx; 		
				rcode = msgsnd(clt_send_ptr->lbp_mqid, (char*) cpx_ptr->lbp_mqbuf, 
								sizeof(proxy_hdr_t), 0); 
				if( rcode < 0) ERROR_PRINT(-errno);
				continue;
		}
		
		switch(cpx_ptr->lbp_header->c_cmd){
			case CMD_SEND_MSG:
			case CMD_SNDREC_MSG:
			case CMD_REPLY_MSG:
				break;
			case CMD_COPYIN_DATA:
			case CMD_COPYOUT_DATA:
			case CMD_COPYOUT_RQST:
			case CMD_COPYLCL_RQST:
			case CMD_COPYRMT_RQST:
			case CMD_COPYIN_RQST:
				USRDEBUG("CLIENT_RPROXY(%s):" VCOPY_FORMAT, 
					clt_ptr->clt_name, VCOPY_FIELDS(cpx_ptr->lbp_header)); 
				break;
			default:
				break;
		}
   	}while(cpx_ptr->lbp_header->c_cmd == CMD_NONE);
    
	/* now we have a proxy header in the buffer. Cast it.*/
    pl_size = cpx_ptr->lbp_header->c_len;
    
    /* payload could be zero */
    if(pl_size > 0) {
		assert(cpx_ptr->lbp_payload != NULL);
        bzero(cpx_ptr->lbp_payload, pl_size);
        bytes = clt_Rproxy_rcvpay(clt_ptr);
		USRDEBUG("CLIENT_RPROXY(%s): payload bytes=%d\n",clt_ptr->clt_name, bytes); 
        if (bytes < 0) ERROR_RETURN(bytes);
		return(OK);
	}
    return(OK);
}

int clt_Rproxy_rcvhdr(client_t *clt_ptr)
{
    int n, total,  received = 0;
    char *p_ptr;
	lbpx_desc_t *cpx_ptr; 

	cpx_ptr = &clt_ptr->clt_rpx;
	USRDEBUG("CLIENT_RPROXY(%s): lbp_csd=%d \n", 
			clt_ptr->clt_name, cpx_ptr->lbp_csd);
   	p_ptr = (char*) cpx_ptr->lbp_header;
	assert(p_ptr != NULL);
	total = sizeof(proxy_hdr_t);
   	while ((n = recv(cpx_ptr->lbp_csd, p_ptr, (total-received), 0 )) > 0) {
        received = received + n;
		USRDEBUG("CLIENT_RPROXY (%s): n:%d | received:%d | HEADER_SIZE:%d\n", 
				clt_ptr->clt_name, n,received,sizeof(proxy_hdr_t));
        if (received >= sizeof(proxy_hdr_t)) {  
			USRDEBUG("CLIENT_RPROXY (%s): " CMD_FORMAT,
				clt_ptr->clt_name, CMD_FIELDS(cpx_ptr->lbp_header));
			USRDEBUG("CLIENT_RPROXY (%s): " CMD_XFORMAT, 
				clt_ptr->clt_name, CMD_XFIELDS(cpx_ptr->lbp_header));
        	return(received);
        } else {
			USRDEBUG("CLIENT_RPROXY (%s): Header partially received. There are %d bytes still to get\n", 
                  	clt_ptr->clt_name, sizeof(proxy_hdr_t) - received);
        	p_ptr += n;
        }
   	}
    if( n < 0)  ERROR_RETURN(-errno);
	return(received);
}

int clt_Rproxy_rcvpay(client_t *clt_ptr)
{
    int n, pl_size ,received = 0;
    char *p_ptr;
	lbpx_desc_t *cpx_ptr; 

	cpx_ptr = &clt_ptr->clt_rpx;
	pl_size = cpx_ptr->lbp_header->c_len;
   	USRDEBUG("CLIENT_RPROXY (%s): pl_size=%d\n",clt_ptr->clt_name, pl_size);
   	p_ptr = (char*) cpx_ptr->lbp_payload;
   	while ((n = recv(cpx_ptr->lbp_csd, p_ptr, (pl_size-received), 0 )) > 0) {
        received = received + n;
		USRDEBUG("CLIENT_RPROXY (%s): n:%d | received:%d\n",
			clt_ptr->clt_name, n,received);
        if (received >= pl_size) return(received);
       	p_ptr += n;
   	}
    
    if(n < 0) ERROR_RETURN(-errno);
 	return(received);
}

int clt_Rproxy_svrmq(client_t *clt_ptr, server_t *svr_ptr, 
					sess_entry_t *sess_ptr)
{
    int rcode = 0, svr_ep, ret, cmd, dcid;
	lbpx_desc_t *cpx_ptr; 
	lbpx_desc_t *spx_ptr; 
	proxy_hdr_t *hdr_ptr;
	proxy_payload_t *pay_ptr;
	
	cpx_ptr = &clt_ptr->clt_rpx;
	spx_ptr = &svr_ptr->svr_spx;
	
	// Modify CLIENT RECEIVER header 
	hdr_ptr = cpx_ptr->lbp_header;
	hdr_ptr->c_snode = lb.lb_nodeid;
	m_ptr   = &hdr_ptr->c_u.cu_msg;
	dcid = spx_ptr->lbp_header->c_dcid;
	USRDEBUG("CLIENT_RPROXY(%s) BEFORE: " CMD_FORMAT, clt_ptr->clt_name, CMD_FIELDS(hdr_ptr));
	MTX_LOCK(sess_table[dcid].st_mutex);
	hdr_ptr->c_dnode = sess_ptr->se_svr_nodeid;
	
	// modify VCOPY subheader fields
	cmd = (hdr_ptr->c_cmd & ~MASK_ACKNOWLEDGE);
	if( cmd >= CMD_COPYIN_DATA && cmd <= CMD_COPYIN_RQST){
		USRDEBUG("CLIENT_RPROXY(%s) VCOPY BEFORE: " VCOPY_FORMAT, 
			clt_ptr->clt_name, VCOPY_FIELDS(hdr_ptr));
		// MODIFY THE VCOPY DESTINATION
		if( hdr_ptr->c_u.cu_vcopy.v_rqtr == hdr_ptr->c_dst){
			hdr_ptr->c_u.cu_vcopy.v_rqtr = sess_ptr->se_svr_ep; 
		} 
		if( hdr_ptr->c_u.cu_vcopy.v_src == hdr_ptr->c_dst){
			hdr_ptr->c_u.cu_vcopy.v_src = sess_ptr->se_svr_ep; 
		} 
		if( hdr_ptr->c_u.cu_vcopy.v_dst == hdr_ptr->c_dst){
			hdr_ptr->c_u.cu_vcopy.v_dst = sess_ptr->se_svr_ep; 
		}
		// MODIFY THE VCOPY SOURCE
		if( hdr_ptr->c_u.cu_vcopy.v_rqtr == hdr_ptr->c_src){
			hdr_ptr->c_u.cu_vcopy.v_rqtr = sess_ptr->se_lbsvr_ep; 
		} 
		if( hdr_ptr->c_u.cu_vcopy.v_src == hdr_ptr->c_src){
			hdr_ptr->c_u.cu_vcopy.v_src = sess_ptr->se_lbsvr_ep; 
		} 
		if( hdr_ptr->c_u.cu_vcopy.v_dst == hdr_ptr->c_src){
			hdr_ptr->c_u.cu_vcopy.v_dst = sess_ptr->se_lbsvr_ep; 
		}		
		USRDEBUG("CLIENT_RPROXY(%s) VCOPY AFTER: " VCOPY_FORMAT, 
			clt_ptr->clt_name, VCOPY_FIELDS(hdr_ptr));		
	} else { // a MESSAGE 
		m_ptr->m_source = sess_ptr->se_lbsvr_ep;
	}
	hdr_ptr->c_src = sess_ptr->se_lbsvr_ep;
	hdr_ptr->c_dst = sess_ptr->se_svr_ep; 

	if( hdr_ptr->c_len > 0)
		hdr_ptr->c_pl_ptr	= (unsigned long) cpx_ptr->lbp_payload; //  changed field  c_pl_ptr is really c_snd_seq 
	MTX_UNLOCK(sess_table[dcid].st_mutex);
	// End Modify 
	
	USRDEBUG("CLIENT_RPROXY(%s) AFTER: " CMD_FORMAT, clt_ptr->clt_name, CMD_FIELDS(hdr_ptr));

	USRDEBUG("CLIENT_RPROXY(%s): sending HEADER %d bytes to server %s by mqid=%d\n", 
		clt_ptr->clt_name, sizeof(proxy_hdr_t), svr_ptr->svr_name, spx_ptr->lbp_mqid);
	cpx_ptr->lbp_mqbuf->mb_type = LBP_CLT2SVR;	
	rcode = msgsnd(spx_ptr->lbp_mqid, (char*) cpx_ptr->lbp_mqbuf, sizeof(proxy_hdr_t), 0); 
	if( hdr_ptr->c_len > 0){
		USRDEBUG("CLIENT_RPROXY(%s): getting new Payload buffer\n", clt_ptr->clt_name);
		// Allocate a NEW buffer for payload 
		ret = posix_memalign( (void**) &cpx_ptr->lbp_payload, getpagesize(), MAXCOPYBUF);
		if (ret != 0) ERROR_EXIT(ret);
		USRDEBUG("CLIENT_RPROXY(%s): Payload address=%p\n", clt_ptr->clt_name, cpx_ptr->lbp_payload);
	}
	if( rcode < 0) ERROR_RETURN(-errno);
	return(rcode);
}

/*----------------------------------------------*/
/*----------------------------------------------*/
/*----------------------------------------------*/
/*      PROXY SENDER FUNCTIONS          */
/*----------------------------------------------*/
/*----------------------------------------------*/
/*----------------------------------------------*/

/*===========================================================================*
 *				   clt_Sproxy 				    					 *
 *===========================================================================*/
void *clt_Sproxy(void *arg)
{
	int clt_id = (int) arg;
   	client_t *clt_ptr;
	
	USRDEBUG("CLIENT_SPROXY[%d]: Initializing...\n", clt_id);
	clt_ptr = &client_tab[clt_id];
	clt_Sproxy_init(clt_ptr);
	clt_Sproxy_loop(clt_ptr);
	USRDEBUG("CLIENT_SPROXY[%d]: Exiting...\n", clt_id);
}	

void  clt_Sproxy_init(	client_t *clt_ptr) 
{
    int rcode = 0;

	lbpx_desc_t *cpx_ptr; 
	cpx_ptr = &clt_ptr->clt_spx;

	USRDEBUG("CLIENT_SPROXY(%s): Initializing proxy sender\n", clt_ptr->clt_name);

	rcode = posix_memalign( (void**) &cpx_ptr->lbp_mqbuf, getpagesize(), (sizeof(msgq_buf_t)));
	if (rcode != 0) ERROR_EXIT(rcode);

	cpx_ptr->lbp_header = &cpx_ptr->lbp_mqbuf->mb_header;
	cpx_ptr->lbp_payload = NULL;

//	rcode = posix_memalign( (void**) &cpx_ptr->lbp_payload, getpagesize(), (sizeof(proxy_payload_t)));
//	if (rcode != 0) ERROR_EXIT(rcode);

    // Create server socket.
    if ( (cpx_ptr->lbp_sd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
       	ERROR_EXIT(errno);
    }
}

void  clt_Sproxy_loop(client_t *clt_ptr)  
{
    int rcode = 0;
	lbpx_desc_t *cpx_ptr; 
	cpx_ptr = &clt_ptr->clt_spx;

	while(1) {
		do {
			if (rcode < 0)
				USRDEBUG("CLIENT_SPROXY(%s): Could not connect. "
                    			"Sleeping for a while...\n",clt_ptr->clt_name);
			sleep(LB_TIMEOUT_5SEC);
			rcode = clt_Sproxy_connect(clt_ptr);
		} while (rcode != 0);
		
		rcode = clt_Sproxy_serving(clt_ptr);
		ERROR_PRINT(rcode);
		close(cpx_ptr->lbp_sd);
	}
   /* code never reaches here */
}

void  clt_Sproxy_connect(client_t *clt_ptr)  
{
    int rcode, i;
    char rmt_ipaddr[INET_ADDRSTRLEN+1];
	lbpx_desc_t *cpx_ptr; 

	cpx_ptr = &clt_ptr->clt_spx;

    cpx_ptr->lbp_port = (LBP_BASE_PORT+lb.lb_nodeid);
	USRDEBUG("CLIENT_SPROXY(%s): remote host port=%d\n", clt_ptr->clt_name, cpx_ptr->lbp_port);    

	// Connect to the server client	
    cpx_ptr->lbp_rmtclt_addr.sin_family = AF_INET;  
    cpx_ptr->lbp_rmtclt_addr.sin_port 	= htons(cpx_ptr->lbp_port);  
    cpx_ptr->lbp_rmthost = gethostbyname(clt_ptr->clt_name);
	if( cpx_ptr->lbp_rmthost == NULL) ERROR_EXIT(h_errno);
	USRDEBUG("CLIENT_SPROXY(%s): rmthost %s IP %s\n", clt_ptr->clt_name, 
		cpx_ptr->lbp_rmthost->h_name, 
		inet_ntoa(*(struct in_addr*)cpx_ptr->lbp_rmthost->h_addr));    

//	if( cpx_ptr->lbp_rmthost == NULL) ERROR_EXIT(h_errno);
//	for( i =0; cpx_ptr->lbp_rmthost->h_addr_list[i] != NULL; i++) {
//		USRDEBUG("CLIENT_SPROXY(%s): remote host address %i: %s\n", clt_ptr->clt_name,
//			i, inet_ntoa( *( struct in_addr*)(cpx_ptr->lbp_rmthost->h_addr_list[i])));
//	}

//    if((inet_pton(AF_INET,inet_ntoa( *( struct in_addr*)(cpx_ptr->lbp_rmthost->h_addr_list[0])), 
//		(struct sockaddr*) &cpx_ptr->lbp_rmtclt_addr.sin_addr)) <= 0)
//    	ERROR_RETURN(-errno);

    if((inet_pton(AF_INET,inet_ntoa( *( struct in_addr*)(cpx_ptr->lbp_rmthost->h_addr)), 
		(struct sockaddr*) &cpx_ptr->lbp_rmtclt_addr.sin_addr)) <= 0)
    	ERROR_RETURN(-errno);

    inet_ntop(AF_INET, (struct sockaddr*) &cpx_ptr->lbp_rmtclt_addr.sin_addr, rmt_ipaddr, INET_ADDRSTRLEN);
	USRDEBUG("CLIENT_SPROXY(%s): running at IP=%s\n", clt_ptr->clt_name, rmt_ipaddr);    

	rcode = connect(cpx_ptr->lbp_sd, (struct sockaddr *) &cpx_ptr->lbp_rmtclt_addr, 
				sizeof(cpx_ptr->lbp_rmtclt_addr));
    if (rcode != 0) ERROR_RETURN(-errno);
	USRDEBUG("CLIENT_SPROXY(%s): connected to IP=%s on socket=%d\n", 
		clt_ptr->clt_name, rmt_ipaddr, cpx_ptr->lbp_sd);    
    return(OK);
}

void  clt_Sproxy_serving(client_t *clt_ptr) 
{
    int rcode = 0;
	lbpx_desc_t *cpx_ptr; 

	cpx_ptr = &clt_ptr->clt_spx;

    while(1) {
		USRDEBUG("CLIENT_SPROXY(%s): Reading message queue..\n", clt_ptr->clt_name);
		
		// Get message from message queue  
		rcode = clt_Sproxy_mqrcv(clt_ptr);
		if( rcode < 0) {
			ERROR_PRINT(rcode);
			sleep(1);
			continue;
		}
		USRDEBUG("CLIENT_SPROXY(%s): " CMD_FORMAT ,clt_ptr->clt_name, 
			CMD_FIELDS(cpx_ptr->lbp_header)); 
		USRDEBUG("CLIENT_SPROXY(%s): " CMD_XFORMAT,clt_ptr->clt_name, 
			CMD_XFIELDS(cpx_ptr->lbp_header)); 
	
#ifdef PROXY_TIMESTAMP	
		timestamp_opt = 1;
		if( timestamp_opt){
			clock_gettime(clk_id, &cpx_ptr->lbp_header->c_timestamp);
			USRDEBUG("CLIENT_SPROXY(%s): " CMD_TSFORMAT, clt_ptr->clt_name, 
				CMD_TSFIELDS(cpx_ptr->lbp_header)); 
		}
#endif // PROXY_TIMESTAMP	

		rcode =  clt_Sproxy_send(clt_ptr);
	}
}

void  clt_Sproxy_send(client_t *clt_ptr) 
{
    int rcode = 0;
	lbpx_desc_t *cpx_ptr; 
	char *p_ptr;

	cpx_ptr = &clt_ptr->clt_spx;

	USRDEBUG("CLIENT_SPROXY(%s): " CMD_FORMAT, clt_ptr->clt_name, 
		CMD_FIELDS(cpx_ptr->lbp_header));
	USRDEBUG("CLIENT_SPROXY(%s): " CMD_XFORMAT, clt_ptr->clt_name, 
		CMD_XFIELDS(cpx_ptr->lbp_header));
		
	/* send the header */
    p_ptr = (char *)cpx_ptr->lbp_header->c_pl_ptr; // Get the pointer from header 
	rcode =  clt_Sproxy_sndhdr(clt_ptr);
	if ( rcode < 0) {
		if( cpx_ptr->lbp_header->c_len > 0)
			FREE(p_ptr);		
		ERROR_RETURN(rcode);
	}
	
	if( cpx_ptr->lbp_header->c_len > 0) {
		USRDEBUG("CLIENT_SPROXY(%s): send payload len=%d\n", 
			clt_ptr->clt_name, cpx_ptr->lbp_header->c_len);
		rcode =  clt_Sproxy_sndpay(clt_ptr);
		// Free the Client Proxy input buffer for payload  
		FREE(p_ptr);
		if ( rcode != OK) ERROR_RETURN(rcode);
	}
    return(OK);
}
	
void  clt_Sproxy_sndhdr(client_t *clt_ptr) 
{
    int rcode = 0;
	int sent = 0;        // how many bytes we've sent
    int bytesleft;
    int n, total;
	char *p_ptr;
	lbpx_desc_t *cpx_ptr;

	cpx_ptr = &clt_ptr->clt_spx;
	bytesleft = sizeof(proxy_hdr_t); // how many bytes we have left to send
	total = bytesleft;
	USRDEBUG("CLIENT_SPROXY(%s): send header=%d \n", clt_ptr->clt_name, bytesleft);

    p_ptr = (char *) cpx_ptr->lbp_header;
	USRDEBUG("CLIENT_SPROXY(%s): " CMD_FORMAT, clt_ptr->clt_name, 
		CMD_FIELDS(cpx_ptr->lbp_header));
	USRDEBUG("CLIENT_SPROXY(%s): " CMD_XFORMAT, clt_ptr->clt_name, 
		CMD_XFIELDS(cpx_ptr->lbp_header));

    while(sent < total) {
        n = send(cpx_ptr->lbp_sd, p_ptr, bytesleft, 0);
        if (n < 0) {
			ERROR_PRINT(n);
			if(errno == EALREADY) {
				ERROR_PRINT(errno);
				sleep(1);
				continue;
			}else{
				ERROR_RETURN(-errno);
			}
		}
        sent += n;
		p_ptr += n; 
        bytesleft -= n;
    }
	USRDEBUG("CLIENT_SPROXY(%s): sent header=%d \n", clt_ptr->clt_name, total);
    return(OK);

}	

void  clt_Sproxy_sndpay(client_t *clt_ptr) 
{
    int rcode = 0;
    int sent = 0;        // how many bytes we've sent
    int bytesleft;
    int n, total;
	char *p_ptr;
	lbpx_desc_t *cpx_ptr;
	proxy_hdr_t *hdr_ptr;


	cpx_ptr = &clt_ptr->clt_spx;

	assert( cpx_ptr->lbp_header->c_len > 0);

	bytesleft =  cpx_ptr->lbp_header->c_len; // how many bytes we have left to send
	total = bytesleft;
	USRDEBUG("CLIENT_SPROXY(%s): clt_Sproxy_sndpay bytesleft=%d \n", 
		clt_ptr->clt_name, bytesleft);

    hdr_ptr = (char *) cpx_ptr->lbp_header;
	USRDEBUG("CLIENT_SPROXY(%s): " VCOPY_FORMAT, 
			clt_ptr->clt_name, VCOPY_FIELDS(hdr_ptr));
			
//    p_ptr = (char *) cpx_ptr->lbp_payload;
    p_ptr = (char *)cpx_ptr->lbp_header->c_pl_ptr; // Get the pointer from header 
	USRDEBUG("CLIENT_SPROXY(%s): " VCOPY_FORMAT, 
		clt_ptr->clt_name, VCOPY_FIELDS(cpx_ptr->lbp_header));
		
    while(sent < total) {
        n = send(cpx_ptr->lbp_sd, p_ptr, bytesleft, 0);
		USRDEBUG("CLIENT_SPROXY(%s): payload sent=%d \n",clt_ptr->clt_name, n);
        if (n < 0) {
			if(errno == EALREADY) {
				ERROR_PRINT(errno);
				sleep(1);
				continue;
			}else{
				ERROR_RETURN(-errno);
			}
		}
        sent += n;
		p_ptr += n; 
        bytesleft -= n;
    }
	USRDEBUG("CLIENT_SPROXY(%s): sent payload=%d \n", clt_ptr->clt_name, total);
    return(OK);
}	

int clt_Sproxy_mqrcv(client_t *clt_ptr)
{
    int rcode = 0;
	lbpx_desc_t *cpx_ptr;

	cpx_ptr = &clt_ptr->clt_spx;
	USRDEBUG("CLIENT_SPROXY(%s): reading from mqid=%d \n", 
		clt_ptr->clt_name, cpx_ptr->lbp_mqid);
	rcode = msgrcv(cpx_ptr->lbp_mqid, cpx_ptr->lbp_mqbuf, sizeof(proxy_hdr_t), 0, 0 );
	if( rcode < 0) ERROR_RETURN(-errno);
	USRDEBUG("CLIENT_SPROXY(%s): %d bytes received\n", 
		clt_ptr->clt_name, rcode);
	return(rcode);
}


