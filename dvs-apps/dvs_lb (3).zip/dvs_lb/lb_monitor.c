/****************************************************************/
/* 				LB_monitor							*/
/* LOAD BALANCER MONITOR 				 		*/
/****************************************************************/

#define _GNU_SOURCE     
#define _MULTI_THREADED
#include "lb_dvs.h"
#include "lb_spread.h"

int lbm_reg_msg(char *sender_ptr, lb_t *lb_ptr, int16 msg_type);

/*===========================================================================*
 *				   lb_monitor 				    					 *
 *===========================================================================*/
void *lb_monitor(void *arg)
{
	int rcode;
    lb_t *lb_ptr;
	
	lb_ptr = &lb;
	
	USRDEBUG("LB MONITOR: Initializing...\n");
	
	init_control_vars(lb_ptr);
    connect_to_spread(lb_ptr);		//establish connection to spread network and joins a group (fixed at lb_ptr->lb_sp_group)
    
    while(TRUE){
        USRDEBUG(LB1_FORMAT, LB1_FIELDS(lb_ptr));
        USRDEBUG(LB2_FORMAT, LB2_FIELDS(lb_ptr));
        
        rcode = lbm_SP_receive(lb_ptr);		//loop receiving messages
        USRDEBUG("rcode=%d\n", rcode);
        if(rcode < 0 ) {
            ERROR_PRINT(rcode);
            sleep(LB_TIMEOUT_5SEC);		
            if( rcode == EDVSNOTCONN) {
                connect_to_spread(lb_ptr);
            }
        }
    }
    
    pthread_exit(NULL);
	USRDEBUG("LB MONITOR: Exiting...\n");
}	

/*===========================================================================*
 *				init_spread				     
 *===========================================================================*/
void init_spread(void)
{
    int rcode;
#ifdef SPREAD_VERSION
    int     mver, miver, pver;
#endif
    
    lb_timeout.sec  = LB_TIMEOUT_5SEC;
    lb_timeout.usec = LB_TIMEOUT_MSEC;
    
#ifdef SPREAD_VERSION
    rcode = SP_version( &mver, &miver, &pver);
    if(!rcode)     {
        SP_error (rcode);
        ERROR_EXIT(rcode);
    }
    USRDEBUG("Spread library version is %d.%d.%d\n", mver, miver, pver);
#else
    USRDEBUG("Spread library version is %1.2f\n", SP_version() );
#endif
}

/*===========================================================================*
 *				connect_to_spread				     
 *===========================================================================*/
void connect_to_spread(lb_t *lb_ptr)
{
    int rcode;
    /*------------------------------------------------------------------------------------
	* lb_mbr_name:  it must be unique in the spread node.
	*--------------------------------------------------------------------------------------*/
    sprintf(lb_ptr->lb_sp_group, "%s", SPREAD_GROUP);
    USRDEBUG("spread_group=%s\n", lb_ptr->lb_sp_group);
    sprintf( Spread_name, "4803");
	
	sprintf( lb_ptr->lb_mbr_name, "LBM.%02d", lb_ptr->lb_nodeid);
    USRDEBUG("lb_mbr_name=%s\n", lb_ptr->lb_mbr_name);
    
    rcode = SP_connect_timeout( Spread_name,  lb_ptr->lb_mbr_name , 0, 1, 
                               &lb_ptr->lb_mbox, lb_ptr->lb_priv_group, lb_timeout);
							   
    if( rcode != ACCEPT_SESSION ) 	{
        SP_error (rcode);
        ERROR_PRINT(rcode);
        pthread_exit(NULL);
    }
    
    USRDEBUG("lb_mbr_name %s: connected to %s with private group %s\n",
             lb_ptr->lb_mbr_name, Spread_name, lb_ptr->lb_priv_group);
    
    rcode = SP_join( lb_ptr->lb_mbox, lb_ptr->lb_sp_group);
    if( rcode){
        SP_error (rcode);
        ERROR_PRINT(rcode);
        pthread_exit(NULL);
    }
}

/*===========================================================================*
 *				init_control_vars				     
 * nitilize several global and replicated  variables
 *===========================================================================*/
void init_control_vars(lb_t *lb_ptr)
{	
    lb_ptr->lb_bm_nodes 	= 0;
    lb_ptr->lb_bm_init		= 0;	
    lb_ptr->lb_nr_nodes 	= 0;
    lb_ptr->lb_nr_init		= 0;
}

/*===========================================================================*
 *				lbm_SP_receive				    
 *===========================================================================*/
int lbm_SP_receive(lb_t	*lb_ptr)
{
    char        sender[MAX_GROUP_NAME];
    char        target_groups[MAX_MEMBERS][MAX_GROUP_NAME];
    int         num_groups = -1;
    int         service_type = 0;
    int16       mess_type;
    int         endian_mismatch;
    int         ret;
    SP_message *sp_ptr;
    
    USRDEBUG("%s\n", lb_ptr->lb_name);
    
    assert(lb_ptr->lb_mess_in != NULL);
    
    
    memset(lb_ptr->lb_mess_in,0,MAX_MESSLEN);
    //Returns message size in non-error
    ret = SP_receive( lb_ptr->lb_mbox, &service_type, sender, 100, &num_groups, target_groups,
                     &mess_type, &endian_mismatch, MAX_MESSLEN, lb_ptr->lb_mess_in );
    USRDEBUG("ret=%d\n", ret);
    
    if( ret < 0 ){
        if ( (ret == GROUPS_TOO_SHORT) || (ret == BUFFER_TOO_SHORT) ) {
            service_type = DROP_RECV;
            USRDEBUG("\n========Buffers or Groups too Short=======\n");
            ret = SP_receive( lb_ptr->lb_mbox, &service_type, sender, 
                             MAX_MEMBERS, &num_groups, target_groups,
                             &mess_type, &endian_mismatch, MAX_MESSLEN, lb_ptr->lb_mess_in);
        }
    }
    
    if (ret < 0 ) {
        SP_error( ret );
        ERROR_PRINT(ret);
        pthread_exit(NULL);
    }
    
    USRDEBUG("%s: sender=%s Private_group=%s service_type=%d\n", 
             lb_ptr->lb_name,
             sender, 
             lb_ptr->lb_priv_group, 
             service_type);
    
    sp_ptr = (SP_message *) lb_ptr->lb_mess_in;
    
    if( Is_regular_mess( service_type ) )	{
        if( Is_fifo_mess(service_type) ) {
            USRDEBUG("%s: FIFO message from %s, of type %d, (endian %d) to %d groups (%d bytes)\n",
                     lb_ptr->lb_name, sender, mess_type, endian_mismatch, num_groups, ret);
			lb_ptr->lb_len = ret;
			ret = lbm_reg_msg(sender, lb_ptr, mess_type);
        } else {
			USRDEBUG("received non SAFE/FIFO message\n");
            ret = OK;
		}
    } else if( Is_membership_mess( service_type ) )	{
        ret = SP_get_memb_info( lb_ptr->lb_mess_in, service_type, &lb_ptr->lb_memb_info );
        if (ret < 0) {
            USRDEBUG("BUG: membership message does not have valid body\n");
            SP_error( ret );
            ERROR_PRINT(ret);
            pthread_exit(NULL);
        }
        
        if  ( Is_reg_memb_mess( service_type ) ) {
            USRDEBUG("%s: Received REGULAR membership for group %s with %d members, where I am member %d:\n",
                     lb_ptr->lb_name, sender, num_groups, mess_type );
        }
        
        if( Is_caused_join_mess( service_type ) )	{
            /*----------------------------------------------------------------------------------------------------
			*   JOIN: The group has a new LBM  member
			*----------------------------------------------------------------------------------------------------*/
            lbm_udt_members(lb_ptr,target_groups,num_groups);
            
            USRDEBUG("%s: Due to the JOIN of %s service_type=%d\n", 
                     lb_ptr->lb_name, lb_ptr->lb_memb_info.changed_member, service_type );
            
            ret = lbm_join(lb_ptr,num_groups);
        }else if( Is_caused_leave_mess( service_type ) 
                 ||  Is_caused_disconnect_mess( service_type ) ){
            /*----------------------------------------------------------------------------------------------------
			*   LEAVE or DISCONNECT:  A member has left the group
			*----------------------------------------------------------------------------------------------------*/
            lbm_udt_members(lb_ptr,target_groups,num_groups);
            
            USRDEBUG("%s: Due to the LEAVE or DISCONNECT of %s\n", 
                     lb_ptr->lb_name, lb_ptr->lb_memb_info.changed_member );
            
            ret = lbm_leave(lb_ptr,num_groups);
        }else if( Is_caused_network_mess( service_type ) ){
      /*----------------------------------------------------------------------------------------------------
            *   NETWORK CHANGE:  A network partition or a dead deamon
            *----------------------------------------------------------------------------------------------------*/
            USRDEBUG("%s: Due to NETWORK change with %u VS sets\n", 
                     lb_ptr->lb_name,  lb_ptr->lb_num_vs_sets);
            
            ret = lbm_network(lb_ptr);
            
            //@TODO: delete this? Not sure if it they might be useful in the future
        }else if( Is_transition_mess(   service_type ) ) {
            USRDEBUG("received TRANSITIONAL membership for group %s\n", sender );
            if( Is_caused_leave_mess( service_type ) ){
                USRDEBUG("received membership message that left group %s\n", sender );
            }else {
                USRDEBUG("received incorrecty membership message of type 0x%x\n", service_type );
            }
        } else if ( Is_reject_mess( service_type ) )      {
            USRDEBUG("REJECTED message from %s, of servicetype 0x%x messtype %d, (endian %d) to %d groups \n(%d bytes): %s\n",
                     sender, service_type, mess_type, endian_mismatch, num_groups, ret, lb_ptr->lb_mess_in );
        }else {
            USRDEBUG("received message of unknown message type 0x%x with ret %d\n", service_type, ret);
        }
    }
    if(ret < 0) ERROR_RETURN(ret);
    return(ret);
}

/*===========================================================================*
*				get_nodeid				     *
* It converts a node string provided by SPREAD into a NODEID
* format of mbr_string "#LBx.<nodeid>#nodename" 
*===========================================================================*/
int get_nodeid(char *mbr_string)
{
    char *s_ptr, *n_ptr, *dot_ptr;
    int nid, len;
    
    USRDEBUG("mbr_string=%s\n", mbr_string);

    dot_ptr = strchr(mbr_string, '.'); 
    assert(dot_ptr != NULL);
    n_ptr = dot_ptr+1;					
    
    s_ptr = strchr(n_ptr, '#'); 
    assert(s_ptr != NULL);
    
    *s_ptr = '\0';
    nid = atoi(n_ptr);
    *s_ptr = '#';
    USRDEBUG("mbr_string=%s nid=%d\n", mbr_string,  nid );
    
	assert( nid >= 0 && nid < NR_NODES);
    return(nid);
}

/*===========================================================================*
*				lbm_reg_msg				     *
* Handle REGULAR messages 
*===========================================================================*/
int lbm_reg_msg(char *sender_ptr, lb_t *lb_ptr, int16 msg_type)
{
	int agent_id;
	int rcode;
	message *m_ptr;
	server_t *svr_ptr;

	m_ptr = lb_ptr->lb_mess_in;
	agent_id = get_nodeid(sender_ptr);
    USRDEBUG("sender_ptr=%s agent_id=%d msg_type=%d\n", 
				sender_ptr,  agent_id, msg_type);

	// self sent message 
	if ( msg_type == MT_LOAD_THRESHOLDS){
		lb_ptr->lb_nr_init = lb_ptr->lb_nr_nodes;
		lb_ptr->lb_bm_init = lb_ptr->lb_bm_nodes;
		return(OK);
	}
	
	// ignore other self sent messages 
	if( agent_id == lb_ptr->lb_nodeid) return(OK);

	// check that the sender is an initialized agent 
	if (TEST_BIT(lb_ptr->lb_bm_init, agent_id) == 0 ){
		fprintf( stderr,"lbm_reg_msg: agent_id %d is not initialized !\n",
				agent_id);
		// check if it is a valid server 
		SET_BIT(lb_ptr->lb_bm_init, agent_id);
		lb_ptr->lb_nr_init++;
        USRDEBUG(LB2_FORMAT, LB2_FIELDS(lb_ptr));
	}

    USRDEBUG(MSG1_FORMAT, MSG1_FIELDS(m_ptr));
	switch (msg_type){
		case MT_LOAD_LEVEL:
					// check that sender's name be an AGENT name 
			if( strncmp(sender_ptr, LBA_SHARP, strlen(LBA_SHARP)) != 0){
				fprintf( stderr,"lba_reg_msg: MT_LOAD_LEVEL message sent by %s\n",
					 sender_ptr);
				return(OK);					
			}
			// check message len 
			if( lb_ptr->lb_len < sizeof(message)){
				fprintf( stderr,"lb_reg_msg: bad message size=%d (must be %d)\n",
					 lb_ptr->lb_len, sizeof(message));
				return(OK);		
			}
			m_ptr = lb_ptr->lb_mess_in;
			USRDEBUG(MSG1_FORMAT, MSG1_FIELDS(m_ptr) );	
			// check message source 
			if( m_ptr->m_source != agent_id){
				fprintf( stderr,"lb_reg_msg: m_source(%d) != sender agent_id(%d)\n",
					 m_ptr->m_source, agent_id);
				return(OK);		
			}
			// check correct message type 
			if( m_ptr->m_type != msg_type){
				fprintf( stderr,"lb_reg_msg: m_type(%d) != msg_type(%d)\n",
					 m_ptr->m_type, msg_type);
				return(OK);		
			}
			if(TEST_BIT(lb_ptr->lb_bm_init, agent_id) == 0){	
				SET_BIT(lb_ptr->lb_bm_init, agent_id);
				lb_ptr->lb_nr_init++;
				USRDEBUG(LB2_FORMAT, LB2_FIELDS(lb_ptr));
			}	
			assert(m_ptr->m_source == agent_id);
			lbm_lvlchg_msg(m_ptr);
			break;
		default:
			fprintf( stderr,"lbm_reg_msg: Invalid msg_type %d\n", msg_type);
			assert(FALSE);
			break;
	}
	return(OK);
}

/*===========================================================================*
*				lbm_lvlchg_msg				     *
* Handle LEVEL CHANGE messages from SERVER agents to LB Monitor  
*===========================================================================*/
int lbm_lvlchg_msg(message *m_ptr)
{
	int rcode;
	server_t *svr_ptr;

	USRDEBUG(MSG1_FORMAT, MSG1_FIELDS(m_ptr) );	
	
	switch(m_ptr->m1_i1) {
		case LVL_UNLOADED:
		case LVL_LOADED:
		case LVL_SATURATED:
			// check received LOAD VALUES  
			assert(m_ptr->m1_i1 >= LVL_UNLOADED && m_ptr->m1_i1<= LVL_SATURATED);
			assert(m_ptr->m1_i2 >= 0 && m_ptr->m1_i2 <= 100);
			svr_ptr = &server_tab[m_ptr->m_source];
			MTX_LOCK(svr_ptr->svr_mutex);
			svr_ptr->svr_level = m_ptr->m1_i1;
			svr_ptr->svr_load  = m_ptr->m1_i2;
			MTX_UNLOCK(svr_ptr->svr_mutex);	
			USRDEBUG(SERVER_FORMAT, SERVER_FIELDS(svr_ptr));	
			break;
		default:
			assert(FALSE); 
			break;
	}
	return(OK);
}

/*===========================================================================*
*				lbm_join				     *
* Handle JOIN 
*===========================================================================*/
int lbm_join(lb_t *lb_ptr,int num_groups)
{
	int agent_id;
    server_t *svr_ptr;

    USRDEBUG("member=%s\n",lb_ptr->lb_memb_info.changed_member);
    agent_id  = get_nodeid((char *)lb_ptr->lb_memb_info.changed_member);
	
	if( agent_id == lb_ptr->lb_nodeid) {
		if( lb_ptr->lb_nr_nodes > 1) {
			mcast_thresholds(lb_ptr);
		}
		return(OK);
	}
	
    if ( strncmp(lb_ptr->lb_memb_info.changed_member, LBA_SHARP, strlen(LBA_SHARP)) == 0) {
		// check if server has been configured 
		svr_ptr = &server_tab[agent_id];
		if( svr_ptr->svr_nodeid == LB_INVALID){
			fprintf( stderr,"WARNING:Agent of node %d is no a configured Server\n", agent_id);
			return(OK);
		}	
		mcast_thresholds(lb_ptr);
    }
    USRDEBUG(LB2_FORMAT, LB2_FIELDS(lb_ptr));

	return(OK);
}

/*===========================================================================*
*				lbm_leave				     *
* Handle LEAVE OR DISCONNECT
*===========================================================================*/
int  lbm_leave(lb_t *lb_ptr,int num_groups)
{
	int agent_id;
	
    USRDEBUG("member=%s\n",lb_ptr->lb_memb_info.changed_member);
    agent_id  = get_nodeid((char *)lb_ptr->lb_memb_info.changed_member);

    if ( strncmp(lb_ptr->lb_memb_info.changed_member, LBA_SHARP, strlen(LBA_SHARP)) == 0) {
		// ignore self messages
		if( agent_id == lb_ptr->lb_nodeid) return(OK);
		// uninitialized agent 
		if( TEST_BIT(lb_ptr->lb_bm_init, agent_id) == 0) return(OK);
		clear_session(agent_id);
        CLR_BIT(lb_ptr->lb_bm_init, agent_id);
		lb_ptr->lb_nr_init--;
    }
    USRDEBUG(LB2_FORMAT, LB2_FIELDS(lb_ptr));
	return(OK);
}

/*===========================================================================*
*				clear_session				     *
* Clear all sessions with the agent_id as a server node 
*===========================================================================*/
void  clear_session(int agent_id)
{
	sess_entry_t *sess_ptr;
	server_t *svr_ptr;
	
    USRDEBUG("agent_id=%d\n",agent_id);

	// CLEAR all sessions with this agent_id as server node 
	for (int i = 0;i < NR_DCS; i++){ 
		for( int j = 0; j < nr_sess_entries; j++){
			sess_ptr = (sess_entry_t *)sess_table[i].st_tab_ptr;
			if ( sess_ptr->se_clt_nodeid == LB_INVALID) continue;
			if ( sess_ptr->se_svr_nodeid == agent_id) {
				svr_ptr = &server_tab[sess_ptr->se_svr_nodeid];
				MTX_LOCK(sess_table[i].st_mutex);
				sess_ptr->se_clt_nodeid	= LB_INVALID;
				sess_ptr->se_clt_ep		= LB_INVALID;
				sess_ptr->se_clt_PID	= LB_INVALID;
				sess_ptr->se_lbclt_ep	= LB_INVALID;
				sess_ptr->se_lbsvr_ep	= LB_INVALID; 
				sess_ptr->se_svr_nodeid	= LB_INVALID;
				sess_ptr->se_svr_ep		= LB_INVALID;
				sess_ptr->se_svr_PID	= LB_INVALID;
				sess_ptr->se_service	= NULL;	
				sess_table[i].st_nr_sess--;
				MTX_UNLOCK(sess_table[i].st_mutex);
				MTX_LOCK(svr_ptr->svr_mutex);				
				CLR_BIT(svr_ptr->svr_bm_svc, sess_ptr->se_svr_ep);
				MTX_UNLOCK(svr_ptr->svr_mutex);				
			}
			sess_ptr++;
		}
	}
}
		
/*===========================================================================*
*				lbm_network				     *
* Handle NETWORK event
*===========================================================================*/
int lbm_network(lb_t* lb_ptr)
{
	int i, j;
    int ret = 0;
	int agent_id;
	int	bm_nodes;
	int	nr_nodes;
	int	bm_init;
	int	nr_init;
	
    USRDEBUG("\n");
	
    lb_ptr->lb_num_vs_sets = 
        SP_get_vs_sets_info(lb_ptr->lb_mess_in, 
                            &lb_ptr->lb_vssets[0], 
                            MAX_VSSETS, 
                            &lb_ptr->lb_my_vsset_index);
    
    if (lb_ptr->lb_num_vs_sets < 0) {
        USRDEBUG("BUG: membership message has more then %d vs sets."
                 "Recompile with larger MAX_VSSETS\n",
                 MAX_VSSETS);
        SP_error( lb_ptr->lb_num_vs_sets );
        ERROR_EXIT( lb_ptr->lb_num_vs_sets );
    }
    if (lb_ptr->lb_num_vs_sets == 0) {
        USRDEBUG("BUG: membership message has %d vs_sets\n", 
                 lb_ptr->lb_num_vs_sets);
        SP_error( lb_ptr->lb_num_vs_sets );
        ERROR_EXIT( EDVSGENERIC );
    }
        
	nr_nodes = 1; // the monitor 
	nr_init  = 1; // the monitor 
	bm_nodes = 0;
	bm_init  = 0;
	SET_BIT(bm_nodes, lb_ptr->lb_nodeid); // the monitor 
	SET_BIT(bm_init,  lb_ptr->lb_nodeid); // the monitor
		
    for(i = 0; i < lb_ptr->lb_num_vs_sets; i++ )  {
        USRDEBUG("%s VS set %d has %u members:\n",
                 (i  == lb_ptr->lb_my_vsset_index) ?("LOCAL") : ("OTHER"), 
                 i, lb_ptr->lb_vssets[i].num_members );
        ret = SP_get_vs_set_members(lb_ptr->lb_mess_in, &lb_ptr->lb_vssets[i], lb_ptr->lb_members, MAX_MEMBERS);
        if (ret < 0) {
            USRDEBUG("VS Set has more then %d members. Recompile with larger MAX_MEMBERS\n", MAX_MEMBERS);
            SP_error( ret );
            ERROR_EXIT( ret);
        }
        
        /*---------------------------------------------
		* get the bitmap of current members
		--------------------------------------------- */
         for(j = 0; j < lb_ptr->lb_vssets[i].num_members; j++ ) {
            USRDEBUG("\t%s\n", lb_ptr->lb_members[j] );
			// only get the AGENTS
            if ( strncmp(lb_ptr->lb_members[j], LBA_SHARP, strlen(LBA_SHARP)) == 0) {	
                agent_id = get_nodeid(lb_ptr->lb_members[j]);
                SET_BIT(bm_nodes, agent_id);
                nr_nodes++;
                if(TEST_BIT(lb_ptr->lb_bm_init, agent_id) == 0) {
					SET_BIT(bm_init, agent_id);
					nr_init++;
				}
			}
		}
    }
	
    USRDEBUG("OLD " LB2_FORMAT, LB2_FIELDS(lb_ptr));	

	if( lb_ptr->lb_nr_nodes > nr_nodes){
	    USRDEBUG("NETWORK PARTITION \n");		
	}else{
	    USRDEBUG("NETWORK MERGE \n");		
	}
		
	for( i = 0; i < sizeof(lb_ptr->lb_bm_init)*8; i++){
		// the agent was on the old bitmap 
        if(TEST_BIT(lb_ptr->lb_bm_init, i) != 0) {
			// but it is not in the current bitmap 
			if(TEST_BIT(bm_init, i) == 0) {
				clear_session(i);
			}
		}
	}
	
	lb_ptr->lb_bm_init   = bm_init;
	lb_ptr->lb_bm_nodes  = bm_nodes;
	lb_ptr->lb_nr_init   = nr_init;
	lb_ptr->lb_nr_nodes  = nr_nodes;
	
	mcast_thresholds(lb_ptr);

    USRDEBUG("NEW " LB2_FORMAT, LB2_FIELDS(lb_ptr));	
    return(OK);
}

/*===========================================================================*
*				mcast_thresholds				     *
* Multilcast the thresholds to new agent
*===========================================================================*/
void mcast_thresholds(lb_t *lb_ptr)
{
	message m;
	message *m_ptr;
	
	m_ptr = &m;
	m_ptr->m_source = lb_ptr->lb_nodeid;
	m_ptr->m_type   = MT_LOAD_THRESHOLDS;
	m_ptr->m1_i1	= lb_ptr->lb_lowwater;
	m_ptr->m1_i2	= lb_ptr->lb_highwater;
	m_ptr->m1_i3	= lb_ptr->lb_period;

    USRDEBUG(MSG1_FORMAT, MSG1_FIELDS(m_ptr));	
				  
	SP_multicast(lb_ptr->lb_mbox, FIFO_MESS, SPREAD_GROUP,
					MT_LOAD_THRESHOLDS , sizeof(message), (char *) m_ptr);
}

/*===========================================================================*
*				lbm_udt_members				     *
*===========================================================================*/
void lbm_udt_members(lb_t* lb_ptr,char target_groups[MAX_MEMBERS][MAX_GROUP_NAME],
                    int num_groups)
{	
	int nodeid;
	
	lb_ptr->lb_bm_nodes = 0;
	lb_ptr->lb_nr_nodes = 0;
    lb_ptr->lb_sp_nr_mbrs = num_groups;
    memcpy((void*) lb_ptr->lb_sp_members, (void *) target_groups, lb_ptr->lb_sp_nr_mbrs*MAX_GROUP_NAME);
    for(int i=0; i < lb_ptr->lb_sp_nr_mbrs; i++ ){
		nodeid = get_nodeid(&lb_ptr->lb_sp_members[i][0]);
        USRDEBUG("\t%s nodeid=%d\n", &lb_ptr->lb_sp_members[i][0], nodeid);
		SET_BIT(lb_ptr->lb_bm_nodes, nodeid);
		lb_ptr->lb_nr_nodes++;
        USRDEBUG(LB2_FORMAT, LB2_FIELDS(lb_ptr));
    }
}


