//nombre del grupo de spread
#define SPREAD_GROUP "LBGROUP"
#define SHARP_GROUP  "#LBGROUP"
//nombre con el cual se va a identificar al balancer
#define LBM_NAME  "LBM"
#define LBM_SHARP "#LBM"

//Cantidad de nodos que se almacenan en el struct (podria ser diferente en ambos?)
#define MAX_AGENT_NODES NR_NODES
#define LBA_NAME 	"LBA"
#define LBA_SHARP  	"#LBA"

#define MT_LOAD_THRESHOLDS	0x1111		// From MONITOR to AGENTS
#define MT_LOAD_LEVEL		0x2222		// From AGENTS to MONITOR 